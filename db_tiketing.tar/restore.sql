--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 10.1
-- Dumped by pg_dump version 10.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.tb_transportasi DROP CONSTRAINT tb_transportasi_id_type_transportasi_fkey;
ALTER TABLE ONLY public.tb_rute DROP CONSTRAINT tb_rute_id_transportasi_fkey;
ALTER TABLE ONLY public.tb_petugas DROP CONSTRAINT tb_petugas_id_level_fkey;
ALTER TABLE ONLY public.tb_pemesanan DROP CONSTRAINT tb_pemesanan_id_pelanggan_fkey;
ALTER TABLE ONLY public.tb_type_transportasi DROP CONSTRAINT tb_type_transportasi_pkey;
ALTER TABLE ONLY public.tb_transportasi DROP CONSTRAINT tb_transportasi_pkey;
ALTER TABLE ONLY public.tb_rute DROP CONSTRAINT tb_rute_pkey;
ALTER TABLE ONLY public.tb_petugas DROP CONSTRAINT tb_petugas_pkey;
ALTER TABLE ONLY public.tb_penumpang DROP CONSTRAINT tb_penumpang_pkey;
ALTER TABLE ONLY public.tb_pemesanan DROP CONSTRAINT tb_pemesanan_pkey;
ALTER TABLE ONLY public.tb_level DROP CONSTRAINT tb_level_pkey;
DROP TABLE public.tb_type_transportasi;
DROP TABLE public.tb_transportasi;
DROP TABLE public.tb_rute;
DROP TABLE public.tb_petugas;
DROP TABLE public.tb_penumpang;
DROP TABLE public.tb_pemesanan;
DROP TABLE public.tb_level;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: tb_level; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tb_level (
    id_level integer NOT NULL,
    nama_level character varying(20)
);


ALTER TABLE tb_level OWNER TO postgres;

--
-- Name: tb_pemesanan; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tb_pemesanan (
    id_pemesanan integer NOT NULL,
    kode_pemesanan character varying(10),
    tanggal_pemesanan date,
    tempat_pemesanan text,
    id_pelanggan character varying(10),
    kode_kursi character varying(10),
    id_rute character varying(10),
    tujuan text,
    tanggal_berangkat date,
    jam_cekin timestamp without time zone,
    jam_berangkat timestamp without time zone,
    total_bayar money,
    id_petugas character varying(10)
);


ALTER TABLE tb_pemesanan OWNER TO postgres;

--
-- Name: tb_penumpang; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tb_penumpang (
    id_penumpang character varying(10) NOT NULL,
    username character varying(20),
    password character varying(20),
    nama_penumpang character varying(50),
    alamat_penumpang text,
    tanggal_lahir date,
    jenis_kelamin character varying(1),
    telefone integer
);


ALTER TABLE tb_penumpang OWNER TO postgres;

--
-- Name: tb_petugas; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tb_petugas (
    id_petugas character varying(10) NOT NULL,
    username character varying(20),
    password character varying(20),
    nama_petugas character varying(50),
    id_level integer
);


ALTER TABLE tb_petugas OWNER TO postgres;

--
-- Name: tb_rute; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tb_rute (
    id_rute character varying(10) NOT NULL,
    tujuan text,
    rute_awal text,
    rute_akhir text,
    harga money,
    id_transportasi integer
);


ALTER TABLE tb_rute OWNER TO postgres;

--
-- Name: tb_transportasi; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tb_transportasi (
    id_transportasi integer NOT NULL,
    kode character varying(10),
    jumlah_kursi integer,
    keterangan text,
    id_type_transportasi character varying(10)
);


ALTER TABLE tb_transportasi OWNER TO postgres;

--
-- Name: tb_type_transportasi; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tb_type_transportasi (
    id_type_transportasi character varying(10) NOT NULL,
    nama_type character varying(50),
    keterangan text
);


ALTER TABLE tb_type_transportasi OWNER TO postgres;

--
-- Data for Name: tb_level; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tb_level (id_level, nama_level) FROM stdin;
\.
COPY tb_level (id_level, nama_level) FROM '$$PATH$$/2839.dat';

--
-- Data for Name: tb_pemesanan; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tb_pemesanan (id_pemesanan, kode_pemesanan, tanggal_pemesanan, tempat_pemesanan, id_pelanggan, kode_kursi, id_rute, tujuan, tanggal_berangkat, jam_cekin, jam_berangkat, total_bayar, id_petugas) FROM stdin;
\.
COPY tb_pemesanan (id_pemesanan, kode_pemesanan, tanggal_pemesanan, tempat_pemesanan, id_pelanggan, kode_kursi, id_rute, tujuan, tanggal_berangkat, jam_cekin, jam_berangkat, total_bayar, id_petugas) FROM '$$PATH$$/2842.dat';

--
-- Data for Name: tb_penumpang; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tb_penumpang (id_penumpang, username, password, nama_penumpang, alamat_penumpang, tanggal_lahir, jenis_kelamin, telefone) FROM stdin;
\.
COPY tb_penumpang (id_penumpang, username, password, nama_penumpang, alamat_penumpang, tanggal_lahir, jenis_kelamin, telefone) FROM '$$PATH$$/2841.dat';

--
-- Data for Name: tb_petugas; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tb_petugas (id_petugas, username, password, nama_petugas, id_level) FROM stdin;
\.
COPY tb_petugas (id_petugas, username, password, nama_petugas, id_level) FROM '$$PATH$$/2840.dat';

--
-- Data for Name: tb_rute; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tb_rute (id_rute, tujuan, rute_awal, rute_akhir, harga, id_transportasi) FROM stdin;
\.
COPY tb_rute (id_rute, tujuan, rute_awal, rute_akhir, harga, id_transportasi) FROM '$$PATH$$/2838.dat';

--
-- Data for Name: tb_transportasi; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tb_transportasi (id_transportasi, kode, jumlah_kursi, keterangan, id_type_transportasi) FROM stdin;
\.
COPY tb_transportasi (id_transportasi, kode, jumlah_kursi, keterangan, id_type_transportasi) FROM '$$PATH$$/2837.dat';

--
-- Data for Name: tb_type_transportasi; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tb_type_transportasi (id_type_transportasi, nama_type, keterangan) FROM stdin;
\.
COPY tb_type_transportasi (id_type_transportasi, nama_type, keterangan) FROM '$$PATH$$/2836.dat';

--
-- Name: tb_level tb_level_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_level
    ADD CONSTRAINT tb_level_pkey PRIMARY KEY (id_level);


--
-- Name: tb_pemesanan tb_pemesanan_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_pemesanan
    ADD CONSTRAINT tb_pemesanan_pkey PRIMARY KEY (id_pemesanan);


--
-- Name: tb_penumpang tb_penumpang_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_penumpang
    ADD CONSTRAINT tb_penumpang_pkey PRIMARY KEY (id_penumpang);


--
-- Name: tb_petugas tb_petugas_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_petugas
    ADD CONSTRAINT tb_petugas_pkey PRIMARY KEY (id_petugas);


--
-- Name: tb_rute tb_rute_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_rute
    ADD CONSTRAINT tb_rute_pkey PRIMARY KEY (id_rute);


--
-- Name: tb_transportasi tb_transportasi_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_transportasi
    ADD CONSTRAINT tb_transportasi_pkey PRIMARY KEY (id_transportasi);


--
-- Name: tb_type_transportasi tb_type_transportasi_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_type_transportasi
    ADD CONSTRAINT tb_type_transportasi_pkey PRIMARY KEY (id_type_transportasi);


--
-- Name: tb_pemesanan tb_pemesanan_id_pelanggan_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_pemesanan
    ADD CONSTRAINT tb_pemesanan_id_pelanggan_fkey FOREIGN KEY (id_pelanggan) REFERENCES tb_penumpang(id_penumpang);


--
-- Name: tb_petugas tb_petugas_id_level_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_petugas
    ADD CONSTRAINT tb_petugas_id_level_fkey FOREIGN KEY (id_level) REFERENCES tb_level(id_level);


--
-- Name: tb_rute tb_rute_id_transportasi_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_rute
    ADD CONSTRAINT tb_rute_id_transportasi_fkey FOREIGN KEY (id_transportasi) REFERENCES tb_transportasi(id_transportasi);


--
-- Name: tb_transportasi tb_transportasi_id_type_transportasi_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_transportasi
    ADD CONSTRAINT tb_transportasi_id_type_transportasi_fkey FOREIGN KEY (id_type_transportasi) REFERENCES tb_type_transportasi(id_type_transportasi);


--
-- PostgreSQL database dump complete
--

